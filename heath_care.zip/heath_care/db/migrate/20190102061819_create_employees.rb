class CreateEmployees < ActiveRecord::Migration[5.2]
  def change
    create_table :employees do |t|
      t.string :username
      t.integer :mobile, :limit=>5
      t.string :email
      t.string :pssword_digest
      t.boolean:admin,:default=>false
      t.boolean :status,:default=>false

      t.timestamps
    end
  end
end
