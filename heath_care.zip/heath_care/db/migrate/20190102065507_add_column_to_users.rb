class AddColumnToUsers < ActiveRecord::Migration[5.2]
  def change
    add_column :employees, :secret,:string
  end
end
