class UserMailer < ApplicationMailer
  default from: 'janarthanan.siva123@gmail.com'
  def welcome_email(email,secure)
    @secrete=secure
    @email=email
    mail(to:email, subject: 'activate your account')
  end
end
