class Employee < ApplicationRecord
  has_secure_password
end
