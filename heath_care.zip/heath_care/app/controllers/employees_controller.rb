class EmployeesController < ApplicationController
  before_action :confirm_logged_in,:except=>[:new,:create]

#-----------alloperation reg settings done here---------------
  def dashboard
    #it just sho  the template
  end
  def user_type
    @employee=Employee.find(session[:userid])
    if @employee.admin==true
      redirect_to(employees_admin_settings_path)
    else
      redirect_to(employees_worker_settings_path)
    end
  end
  def admin_settings
    @employee=Employee.find(session[:userid])
    @employees=Employee.where(:admin=>false)
    @admins=Employee.where(:admin=>true).where.not(:id=>session[:userid])
  end
  def worker_settings
    @employee=Employee.find(session[:userid])
  end
  def update
    @employee=Employee.find(params[:id])
    if @employee.update_attributes(employee_params)
      redirect_to(employees_dashboard_path)
    else
      redirect_to(employees_worker_settings_path)
    end
  end

  def workers_list
  @employee=Employee.where(:admin=>false)
  end
   def make_admin
     @employee=Employee.find(params[:id])
     @employee.admin=true
     @employee.save
     redirect_to(employees_admin_settings_path)
   end
   def remove_admin
     @employee=Employee.find(params[:id])
     @employee.admin=false
     @employee.save
     redirect_to(employees_admin_settings_path)
   end

#  ----- defalut basic actionns done here-------------------
  def new
    @employee=Employee.new
  end
  def create
    @employee=Employee.new(employee_params)
    @employee.secret=SecureRandom.hex(64)
    employee=@employee
    if @employee.save
      UserMailer.with(employee:employee).welcome_email(employee.email,employee.secret).deliver_now
      redirect_to(access_workerlogin_path)
    else
      render 'new'
    end

  end

  private
  def employee_params
    params.require(:employee).permit(:username,:mobile,:email,:password)
  end
end
