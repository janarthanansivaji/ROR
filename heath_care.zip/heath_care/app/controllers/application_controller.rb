class ApplicationController < ActionController::Base
  private
  def confirm_logged_in
    unless session[:userid]
      redirect_to(access_logout_path)
    end
  end
end
