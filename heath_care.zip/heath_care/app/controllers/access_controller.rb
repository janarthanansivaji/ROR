class AccessController < ApplicationController
  def workerlogin
      @employee=Employee.new
  end

  def validate_account
    if params[:email].present? && params[:secret].present?
      found_employee=Employee.where(:email=>params[:email],:secret=>params[:secret]).first
      if found_employee
        found_employee.status=true
        found_employee.save
        redirect_to(access_workerlogin_path)
      else
        redirect_to(new_employee_path)
      end
    end

  end
  def worker_login_attempt
    if params[:email].present? && params[:password].present?
      found_employee=Employee.where(:email=>params[:email],).first
      if(found_employee.status)
        if found_employee
          auth_employee=found_employee.authenticate(params[:password])
        else
          redirect_to(access_workerlogin_path)
        end
      else
        render 'active_alert'
      end
        if auth_employee
        session[:userid]=auth_employee.id
        session[:username]=auth_employee.username
        redirect_to(employees_dashboard_path)
      end
    end
  end
  def logout
    session[:userid]=nil
    redirect_to(access_workerlogin_path)
  end

end
