Rails.application.routes.draw do
  #get 'employees/new'
  #get 'employees/delete'
  #get 'employees/edit'
  get 'access/workerlogin'
  post 'access/worker_login_attempt'
  get 'access/validate_account'
  get 'access/logout'

  get 'employees/user_type'
  get 'employees/dashboard'
  get 'employees/worker_settings'
  get 'employees/admin_settings'
  get 'employees/workers_list'

  #get 'validate_account/:secret/:email', to: 'access#validate_account',as:'validate'
# get '/patients/:id', to: 'patients#show', as: 'patient'
  resources :employees do
    member do
      get :delete
      get :make_admin
      get :remove_admin
    end
  end
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
